package com.sakthi.project.service;

;
import com.sakthi.project.dto.PatientDto;

import java.util.List;

public interface PatientService {

    PatientDto registerPatient(PatientDto dto);

   PatientDto updatePatient(PatientDto dto);

    void deletePatient(Long id);
    //List<PatientDto> findByName(String name);

    List<PatientDto> visitedTenDaysBack(PatientDto dto);


}
