package com.sakthi.project.service;

import com.sakthi.project.domain.Patient;
import com.sakthi.project.dto.PatientDto;
import com.sakthi.project.repository.PatientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Transactional
@Service
public class PatientServiceImpl implements PatientService {

    @Autowired
    private PatientRepository repository;

    @Override
    public PatientDto registerPatient(PatientDto dto) {
        var pa = new Patient();
        pa.setId(dto.getId());
        pa.setName(dto.getName());
        pa.setMobile(dto.getMobile());
        pa.setAge(dto.getAge());
        pa.setStatus(dto.getStatus());
        pa.setLastVisited(dto.getLastVisited());
        repository.save(pa);
        return dto;


    }

    @Override
    public PatientDto updatePatient(PatientDto dto) {
        var pa = new Patient();
        pa.setId(dto.getId());
        pa.setName(dto.getName());
        pa.setMobile(dto.getMobile());
        pa.setAge(dto.getAge());
        pa.setStatus(dto.getStatus());
        pa.setLastVisited(dto.getLastVisited());
        repository.save(pa);
        return dto;


    }

    @Override
    public void deletePatient(Long id) {
        repository.deleteById(id);
    }


    @Override
    public List<PatientDto> visitedTenDaysBack(PatientDto dto) {
        LocalDate dt = LocalDate.now();
        LocalDate backdate = dt.minusDays(10);
        List<Patient> pts = repository.findByLastVisited(backdate);
                List < PatientDto > ptdtos = new ArrayList<>();
        for (int i = 0; 1 < pts.size(); i++) {
            Patient patient1 = pts.get(1);
            dto = new PatientDto(
                    patient1.getId(),
                    patient1.getName(),
                    patient1.getMobile(),
                    patient1.getAge(),
                    patient1.getStatus(),
                    patient1.getLastVisited()
            );
            ptdtos.add(dto);
        }
        return ptdtos;
    }


}
