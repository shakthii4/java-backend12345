package com.sakthi.project.controller;

import com.sakthi.project.dto.AppResponse;
import com.sakthi.project.dto.PatientDto;
import com.sakthi.project.service.PatientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RequestMapping("/abc")
@RestController
public class PatientController {
    @Autowired
    private PatientService service;

    @PostMapping
    public ResponseEntity<AppResponse<PatientDto>> regiterPatient(@RequestBody PatientDto dto) {

        var svObj = service.registerPatient(dto);
        var response = new AppResponse<PatientDto>();
        response.setStatus("success");
        response.setMessage("Data saved successfully");
        response.setBody(svObj);

        return ResponseEntity.ok(response);
    }

    @PutMapping("/update")
    public ResponseEntity<AppResponse<PatientDto>> updatePatient(@RequestBody PatientDto dto) {
        var svObj = service.updatePatient(dto);
        var response = new AppResponse<PatientDto>();
        response.setStatus("success");
        response.setMessage("Data updated successfully");
        response.setBody(svObj);
        return ResponseEntity.ok(response);


   }

   @GetMapping("/hi")
    public ResponseEntity<AppResponse<PatientDto>> visitedTenDaysBack(@RequestBody PatientDto dto)
    {
        var svOb=service.visitedTenDaysBack(dto);
        var response=new AppResponse<PatientDto>();
        response.setStatus("suceess");
        response.setMessage("Successfully visited");
        response.setBody(dto);
        return ResponseEntity.ok(response);



    }


    @DeleteMapping("/{id}")
    public ResponseEntity<AppResponse<Long>> deletePatient(@PathVariable Long id) {
        service.deletePatient(id);
        var response = new AppResponse<Long>();
        response.setMessage("Deleted SuccessFully");
        response.setStatus("Success");
        response.setBody(1l);
        return ResponseEntity.ok(response);
    }

 /*  @GetMapping("/name")
  public ResponseEntity<AppResponse<String>> findUserByName(@PathVariable String name)
  {
      String sm=service.(name);
      var response=new AppResponse<String>();
      response.setMessage("Find User By Name Success ");
      response.setStatus("Success");
      response.setBody(sm);
      return ResponseEntity.ok(response);


  }

*/
}