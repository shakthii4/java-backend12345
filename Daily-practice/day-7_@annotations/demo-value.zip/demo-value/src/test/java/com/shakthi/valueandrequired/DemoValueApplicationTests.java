package com.shakthi.valueandrequired;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoValueApplicationTests {

	@Test
	void contextLoads() {
	}

}
